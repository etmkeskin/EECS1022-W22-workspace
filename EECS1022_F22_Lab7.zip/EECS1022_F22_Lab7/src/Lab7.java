
public class Lab7 {
	
	public static String arrayResult(int[][] array) {
		
		return "";
	}
	
	public static boolean magicSquare(int[][] array) {
		
		return false;
	}
	
}

class Patient {
	
	
}

class Physician {
	
	
}