import java.util.Scanner;

public class Lab5Console {
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in); 
		
		//test printStars()
		System.out.println(Lab5.printStars(1));		
		
		//test expand()
		System.out.println(Lab5.expand(2,1));	
		
		//test getSeqStat()
		System.out.println(Lab5.getSeqStat(1,2,3));	
		
		//test seqInterleaving()
		System.out.println(Lab5.seqInterleaving(1,2,3,1,2,3));	
	}	
}
